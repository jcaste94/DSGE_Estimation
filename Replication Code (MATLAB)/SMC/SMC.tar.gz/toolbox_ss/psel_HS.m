function [parasel, paranames] = psel_HS(para)
%  originally this function is to pick up parameters according to the 
%  model specification (we don't use here)

paranames = { ...
'theta1  '; ...
'theta2 '; ...
};
             
parasel = para;
